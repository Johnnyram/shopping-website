from django.forms import ModelForm
from .models import Auction_listing
from .models import listing

from django import forms

class Auction_listingForm(forms.ModelForm):
    auction_name = forms.CharField(widget=forms.TextInput(attrs={"class":"form-control", "placeholder":"Product name" }))
    bid = forms.IntegerField(widget=forms.TextInput(attrs={"class":"form-control", "placeholder":"Bid price" }))
    comment = forms.CharField(widget=forms.Textarea(attrs={"class":"form-control", "placeholder":"Description" }))
    Image = forms.ImageField(widget=forms.FileInput(attrs={"class":"form-control"}))

    class Meta:
        model = Auction_listing
        fields = ['auction_name','bid','comment','add_photo','Image','categories']

class listingForm(forms.ModelForm):
    user_comment = forms.CharField(required=False, widget=forms.TextInput(attrs={"class":"form-control", "placeholder":"Type a comment" }))
    new_bid = forms.IntegerField(widget=forms.TextInput(attrs={"class":"form-control", "placeholder":"Bid must be higher then previous bid." }))    
    class Meta:
        model = listing
        fields = ['new_bid','user_comment']

