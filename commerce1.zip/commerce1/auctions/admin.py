from django.contrib import admin

# Register your models here.
from .models import Auction_listing
from .models import listing
from .models import Cart


class Auction_listingAdmin(admin.ModelAdmin):
	list_display = ("auction_name","bid","id")
	readonly_fields = ('id',)

class listingAdmin(admin.ModelAdmin):
	list_display = ("new_bid","user_comment","id")
	readonly_fields = ('id',)

class CartAdmin(admin.ModelAdmin):
	list_display = ("users","id")
	readonly_fields = ('id',)

admin.site.register(Auction_listing, Auction_listingAdmin)
admin.site.register(listing, listingAdmin)
admin.site.register(Cart, CartAdmin)
