from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models import Model
from datetime import datetime

CHOICES = (
    ('clothes','CLOTHES'),
    ('consumer_electronics', 'CONSUMER ELECTRONICS'),
    ('vehicles','VEHICLES'),
    ('real_estate','REAL ESTATE'),
    ('jewellry','JEWELLRY'),
    ('books','BOOKS'),
    ('cosmetics','COSMETICS'),
    ('furnitures','FURNITURES')
)

class User(AbstractUser):
	pass

class Auction_listing(models.Model):
	auction_name = models.CharField(max_length=64, null=True)
	bid = models.FloatField(null=True)
	comment = models.TextField(max_length=300, null=True)
	add_photo = models.BooleanField(default=False)
	Image = models.ImageField(upload_to='auctions/images', null=True, default=False, blank=True)
	author = models.ForeignKey(User, on_delete=models.CASCADE, default=False, db_constraint=False, related_name="author")
	categories = models.CharField(max_length=64, choices=CHOICES, default="uncategorized")
	time = models.DateTimeField(default=datetime.now(), blank=True)

	def __str__(self):
		return f"{self.id}:{self.auction_name},price is {self.bid},{self.comment},add photo {self.add_photo} in {self.categories} at {self.time}"

class listing(models.Model):
	new_bid = models.FloatField(null=True)
	user_comment = models.CharField(max_length=64, null=True, default=False, blank=True)
	auction = models.ManyToManyField(Auction_listing, blank=True, related_name="Listing")
	user = models.ForeignKey(User, on_delete=models.CASCADE, default=False, db_constraint=False)

	def __str__(self):
		return f"New bid:${self.new_bid} {self.user_comment}"

class Cart(models.Model):
	users = models.OneToOneField(User,on_delete=models.CASCADE,null=True)
	product = models.ManyToManyField(Auction_listing, null=True, blank=True)

	def __str__(self):
		return f"{self.id}"
