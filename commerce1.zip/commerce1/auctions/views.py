from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.core.files.storage import FileSystemStorage
from django.shortcuts import redirect

from .forms import Auction_listingForm
from .forms import listingForm
from .models import User
from .models import Auction_listing
from .models import listing
from .models import Cart


liste=[]

def index(request):
    try:
        the_id = request.session['watchli']
    except:
        the_id = None
    if the_id:
        cart = Cart.objects.get(id=the_id)
    else:
        cart=None
    return render(request, "auctions/index.html", {
        "auction":Auction_listing.objects.all(),
        "cart":cart
    })


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")

def product(request):
    if request.method == "POST":
        forms = Auction_listingForm(request.POST, request.FILES)
        if forms.is_valid():
            forms.save()
            return HttpResponseRedirect(reverse("index"))
    return render(request, "auctions/add.html", {
        "forms": Auction_listingForm,
    })

def listing(request,id):
    global liste
    try:
        the_id = request.session['watchli']
    except:
        the_id = None
    if the_id:
        cart = Cart.objects.get(id=the_id)
    else:
        cart=None
    new=Auction_listing.objects.get(pk=id)
    old=new.bid
    if request.method == "POST":
        form = listingForm(request.POST)
        if form.is_valid():
            new_bid = form.cleaned_data.get("new_bid")
            user_comment = form.cleaned_data.get("user_comment")
            form.save()
            if new_bid > old:
                if request.user.is_authenticated:
                    Auction_listing.objects.filter(pk=id).update(bid=new_bid)
                    return HttpResponseRedirect(reverse("listing", args=(id,)))
                else:
                    return HttpResponseRedirect(reverse("register"))
            else:
                return HttpResponseRedirect(reverse("listing", args=(id,)))

    return render(request, "auctions/listings.html", {
        "form":listingForm,
        "value":new,
        "cart":cart
    })

def watchlist(request): 
    id=0
    l=[]
    try:
        the_id = request.session['watchli']
    except:
        new_cart = Cart()
        new_cart.save()
        request.session['watchli']=new_cart.id
        the_id = new_cart.id
    cart = Cart.objects.get(id=the_id)
    request.session['watchli_total']=cart.product.count()
    #print(dir(request.session))
    if request.user.is_authenticated:
        if request.method == "POST":
            watchlist = request.POST["watchlist"]
            #watch=Auction_listing.objects.get(pk=watchlist)
            #print(watch.id)
            #liste.append(watch)
            #id+=watch.id
            

            try:
                watch=Auction_listing.objects.get(pk=watchlist)
            except Auction_listing.DoesNotExist:
                pass
            except:
                pass
            if not watch in cart.product.all():
                cart.product.add(watch)
            else:
                cart.product.remove(watch)

            #Cart.product.add(watch)
            #Cart.save()
            #carts = Cart.objects.get(id=watch.id)
            #if not watch in carts.product.all():
             #   cart.product.add(watchlist)
              #  cart.save()    
            
            #watchli = request.session.get('watchli', [])
            #watchli.append({'id':watch.id})
            #print(watchli)
            #for i in range(len(watchli)):
                #print(watchli[i]['id'])
                #l=[]
                #l.append(Auction_listing.objects.get(pk=watchli[i]['id']))
            #print(l)
        #else:
            #request.session['name'] = request.user.username
            #print(request.session.get("name", "Unknown"))
            #watchli = request.session.get('watchli', [])
            #for i in range(len(watchli)):
             #   print(watchlist[i]['id'])
              #  l=[]
               # l.append(Auction_listing.objects.get(pk=watchlist[i]['id']))
            #print(l)

        #watchlist.append({'id':watch.id})
        #cart = request.session.get('cart', [])
        #cart.append({'style':s,'choice'c})

        #request.session['cart']=cart
        #request.session['watchlist'].append([{'id':watch.id}])
        #if "watchlist" not in request.session:
            #request.session["watchlist"] = []

        #else:
            #request.session["watchlist"].append(watch)
    else:
        return HttpResponseRedirect(reverse("register"))
    return render(request,"auctions/watchlist.html", {
        #"liste":request.session["watchlist"],
        #"session":request.session["watchlist"],
        "cart":cart,
        "id":id
    })
    
def remove(request): 
    if request.method == "POST":
        remove = request.POST["remove"]
        delete=Auction_listing.objects.get(pk=remove)
        cart.product.remove(delete)
    return render(request,"auctions/watchlist.html", {
        "cart":Cart.objects.all()
    })

def categories(request):
    global liste
    cat=None
    if request.method == "POST":
        if request.POST.get("clothes") !=None:
            clothes = request.POST["clothes"]
            cat=Auction_listing.objects.filter(categories=clothes)

        elif request.POST.get("vehicles") !=None:
            vehicles = request.POST["vehicles"]
            cat=Auction_listing.objects.filter(categories=vehicles)
        
        elif request.POST.get("consumer_electronics") !=None:
            consumer_electronics = request.POST["consumer_electronics"]
            cat=Auction_listing.objects.filter(categories=consumer_electronics)

        elif request.POST.get("real_estate") !=None:
            real_estate = request.POST["real_estate"]
            cat=Auction_listing.objects.filter(categories=real_estate)
        
        elif request.POST.get("jewellry") !=None:
            jewellry = request.POST["jewellry"]
            cat=Auction_listing.objects.filter(categories=jewellry)
        
        elif request.POST.get("books") !=None:
            books = request.POST["books"]
            cat=Auction_listing.objects.filter(categories=books)
        
        elif request.POST.get("cosmetics") !=None:
            cosmetics = request.POST["cosmetics"]
            cat=Auction_listing.objects.filter(categories=cosmetics)
        
        elif request.POST.get("furnitures") !=None:
            furnitures = request.POST["furnitures"]
            cat=Auction_listing.objects.filter(categories=furnitures)
        return render(request,"auctions/categories.html", {
            "cat":cat
    })

def close(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            close = request.POST["close"]
            delete=Auction_listing.objects.get(pk=close)
            delete.delete()
            return HttpResponseRedirect(reverse("index"))
    else:
        return HttpResponseRedirect(reverse("register"))
    return (request, "auctions/listings.html")
